clc
clear
close all

%% Parameters

m.N = 3;
m.sigma = 4;
m.beta = 2/3;
m.A_vec = [3;1;1];
m.L_vec = [1;2;5];
m.tau_mat = eye(m.N)+2*(1-eye(m.N));
m.t0_mat = 0.05*(1-eye(m.N)); % initial tariffs

i = 1;

%% MPEC

% Initial equilibrium outcomes
t_mat = m.t0_mat;
[w_vec,X_vec,P_vec,wel_vec,lam_mat] = func_eqm_iter(t_mat,m);

% Initial guesses
w0 = w_vec;
X0 = X_vec;
P0 = P_vec;
tar0 = t_mat(:,i);

xx0 = [w0;X0;P0;tar0];

% Bounds and linear constraints
A = []; b = [];
Aeq = [ones(m.N,1);zeros(3*m.N,1)]'; % \sum w_i = 1
beq = 1;

tar_ub = inf*ones(m.N,1);
tar_ub(i) = 0;
tar_lb = -1*ones(m.N,1);
tar_lb(i) = 0;
lb = [zeros(3*m.N,1);tar_lb];
ub = [ones(m.N,1);inf*ones(2*m.N,1);tar_ub];

% Constrained optimization

tic
[xx,fval,exitflag,output,lambda,grad,hess] = ...
   knitromatlab(@(xx)func_obj_mpec(xx,m,i),xx0,A,b,Aeq,beq,lb,ub,@(xx)func_const_mpec(xx,m,i),[],[],'nlpoptions.opt');
toc

w_vec = xx(1:m.N);
X_vec = xx(m.N+1:2*m.N);
P_vec = xx(2*m.N+1:3*m.N);
tar_vec = xx(3*m.N+1:4*m.N);

%% Gradient Descending: Forward Differencing
t_mat = m.t0_mat;
t_vec = t_mat(:,i);

diff = 1;
tol = 1e-6;
cc = 0;
iota = 1;

tic
while diff>tol && cc<1000
    t_mat = m.t0_mat;
    t_mat(:,i) = t_vec;
    g_Wt = func_Wt_forward(t_mat,m,i);
    
    t_vec_new = t_vec+iota*g_Wt;
    t_vec_new(i) = 0; % no tariff on domestic production
    
    diff = max(abs(t_vec_new-t_vec));
    cc = cc+1;
    %disp(diff)
    %disp(cc)
    
    t_vec = t_vec_new;
end
toc















