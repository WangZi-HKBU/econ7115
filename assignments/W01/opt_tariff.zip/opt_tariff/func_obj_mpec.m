function [f,g] = func_obj_mpec(xx,m,i)

% Objective functioin for the optimal tariffs

g = [];

w_vec = xx(1:m.N);
X_vec = xx(m.N+1:2*m.N);
P_vec = xx(2*m.N+1:3*m.N);
tar_vec = xx(3*m.N+1:4*m.N); % vector of optimal tariffs in country i

%wel_vec = X_vec./P_vec;
wel_vec = (X_vec-(1-m.beta)/m.beta*w_vec.*m.L_vec)./P_vec; % welfare

f = -wel_vec(i);

end
