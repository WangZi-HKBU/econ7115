function [w_vec,X_vec,P_vec,wel_vec,lam_mat] = func_eqm_iter(t_mat,m)
% Solve the equilibrium outcomes by iteration

diff = 1;
tol = 1e-8;
cc = 0;
ww = 0.5;

w_vec = ones(m.N,1)/m.N;
X_vec = w_vec.*m.L_vec/m.beta;
P_vec = ones(m.N,1);

while diff>tol && cc <10000
[w_vec_new,X_vec_new,P_vec_new,wel_vec,lam_mat] = func_eqm_update(w_vec,X_vec,P_vec,t_mat,m);

wnum = sum(w_vec_new);
w_vec_new = w_vec_new/wnum;
X_vec_new = X_vec_new/wnum;
P_vec_new = P_vec_new/wnum;

r = [w_vec; X_vec; P_vec];
r_new = [w_vec_new; X_vec_new; P_vec_new];

diff = max(abs(r-r_new));
cc = cc+1;
%disp(diff)
%disp(cc)

w_vec = ww*w_vec_new+(1-ww)*w_vec;
X_vec = ww*X_vec_new+(1-ww)*X_vec;
P_vec = ww*P_vec_new+(1-ww)*P_vec;

end

end

