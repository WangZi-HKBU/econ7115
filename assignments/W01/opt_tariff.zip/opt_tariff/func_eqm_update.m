function [w_vec_new,X_vec_new,P_vec_new,wel_vec,lam_mat] = func_eqm_update(w_vec,X_vec,P_vec,t_mat,m)
% Update the equilibrium outcomes by equilibrium conditions

% Trade shares
kappa_mat = m.tau_mat.*(1+t_mat); % dim1: exporter i; dim2: importer n
K_mat = (repmat(w_vec.^(m.beta).*P_vec.^(1-m.beta)./m.A_vec,[1,m.N]).*kappa_mat).^(1-m.sigma); % dim1: exporter i; dim2: importer n
lam_mat = K_mat./repmat(sum(K_mat,1),[m.N,1]); % dim1: exporter i; dim2: importer n
X_mat = lam_mat.*repmat(X_vec',[m.N,1]); % trade flows---dim1: exporter i; dim2: importer n

% Update
P_vec_new = (sum(K_mat,1)').^(1/(1-m.sigma));

w_vec_new = m.beta./m.L_vec.*sum(X_mat./(1+t_mat),2); % labor market clearing

trev_vec = sum(t_mat./(1+t_mat).*X_mat,1)'; % tariff revenues
X_vec_new = w_vec.*m.L_vec/m.beta+trev_vec;

wel_vec = X_vec./P_vec; % welfare

end

