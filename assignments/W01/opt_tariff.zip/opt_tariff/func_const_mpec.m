function [c,ceq,Gc,Gceq]= func_const_mpec(xx,m,i)
% Equilibrium conditions as constraints
c = [];
Gc = [];
Gceq = [];

w_vec = xx(1:m.N);
X_vec = xx(m.N+1:2*m.N);
P_vec = xx(2*m.N+1:3*m.N);
tar_vec = xx(3*m.N+1:4*m.N); % vector of optimal tariffs in country i

t_mat = m.t0_mat;
t_mat(:,i) = tar_vec;

[w_vec_new,X_vec_new,P_vec_new,~,~] = func_eqm_update(w_vec,X_vec,P_vec,t_mat,m);

ceq = [w_vec_new-w_vec; X_vec_new-X_vec; P_vec_new-P_vec];


end

