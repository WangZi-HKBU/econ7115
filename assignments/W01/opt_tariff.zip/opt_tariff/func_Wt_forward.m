function g_Wt = func_Wt_forward(t_mat,m,i)
% Compute \partial\log W_i/\partial\log(1+t_{ki}) using forward
% differencing

[~,~,~,W0,~] = func_eqm_iter(t_mat,m);

h = 1e-8;
g_Wt = ones(m.N,1);

for k=1:m.N
    t_mat_new = t_mat;
    t_mat_new(k,i) = t_mat(k,i)+h;
    
    [~,~,~,W_new,~] = func_eqm_iter(t_mat_new,m);
    
    g_Wt(k) = (W_new(i)-W0(i))/h*(1+t_mat(k,i))/W0(i);
end


end

